//
//  NextViewController.swift
//  TestCore
//
//  Created by CT on 7/30/18.
//  Copyright © 2018 CT. All rights reserved.
//

import UIKit
import CoreData


class NextViewController: UIViewController
{
    var final_arr:NSMutableArray = NSMutableArray()
    var appDelegate = AppDelegate()
    let imagePicker = UIImagePickerController()
    var chosenImage = UIImage()
    var image_Data = UIImageJPEGRepresentation(UIImage(),0)
    var arr_date:NSMutableArray = NSMutableArray()
    var check:Bool = Bool()
    
    @IBOutlet weak var img_user: UIImageView!
    @IBOutlet weak var txt_name: UITextField!

    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        appDelegate = UIApplication.shared.delegate as! AppDelegate
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        img_user.addGestureRecognizer(tap)
        img_user.isUserInteractionEnabled = true
        imagePicker.delegate = self
        
        let context = appDelegate.persistentContainer.viewContext
        let managedContext = context
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        
        do {
            let results =
                try managedContext.fetch(fetchRequest)
            
            if results.count != 0
            {
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
                
                do {
                    let results = try managedContext.fetch(fetchRequest)
                    let  Locations = results as! [Users]
                    
                    for location in Locations
                    {
                        print(location)
                        print(location.value(forKey: "name") ?? "no name")
                        
                        let data = location.value(forKey: "data") as! NSData
                        let unarchiveObject = NSKeyedUnarchiver.unarchiveObject(with: data as Data)
                        arr_date = unarchiveObject as! NSMutableArray
                        
                        check = true
                    }
                }
                catch let error as NSError
                {
                }
            }
            
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
        

    }
    
    // function which is triggered when handleTap is called
    @objc func handleTap(_ sender: UITapGestureRecognizer)
    {
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler:
            { _ in
                self.openCamera()
        }))
        
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallary()
        }))
        
        alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func openCamera()
    {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            imagePicker.sourceType = UIImagePickerControllerSourceType.camera
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
        else
        {
            let alert  = UIAlertController(title: "Holt Security", message: "You don't have camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func openGallary()
    {
        imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        imagePicker.allowsEditing = true
        self.present(imagePicker, animated: true, completion: nil)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func doclickSave(_ sender: Any)
    {
        if (check == false)
        {
            let dictionaryA = [
                "name": txt_name.text!,
                "image": self.image_Data!,
                ] as [String : Any]
            
            arr_date.add(dictionaryA)
            print(arr_date)
            
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            
            
            let managedContext = context
            let entity =  NSEntityDescription.entity(forEntityName: "Users",
                                                     in:managedContext)
            let device = NSManagedObject(entity: entity!,
                                         insertInto: managedContext)
            let data = NSKeyedArchiver.archivedData(withRootObject: arr_date)
            
            device.setValue(data, forKey: "data")
            do
            {
                try managedContext.save()
                self.navigationController?.popViewController(animated: true)
            }
            catch let error as NSError
            {
                print("Could not save \(error), \(error.userInfo)")
            }
        }
        else
        {
            let dictionaryA = [
                "name": txt_name.text!,
                "image": self.image_Data!,
                ] as [String : Any]
            
            arr_date.add(dictionaryA)
            print(arr_date)
            
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            
            
            let managedContext = context
            let entity =  NSEntityDescription.entity(forEntityName: "Users",
                                                     in:managedContext)
            let device = NSManagedObject(entity: entity!,
                                         insertInto: managedContext)
            let data = NSKeyedArchiver.archivedData(withRootObject: arr_date)
            
            device.setValue(data, forKey: "data")
            do
            {
                try managedContext.save()
                self.navigationController?.popViewController(animated: true)
            }
            catch let error as NSError
            {
                print("Could not save \(error), \(error.userInfo)")
            }
        }
        
       
    }
}

extension NextViewController : UINavigationControllerDelegate, UIImagePickerControllerDelegate
{
    internal func imagePickerControllerDidCancel(_ picker: UIImagePickerController)
    {
        picker.dismiss(animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        if (info[UIImagePickerControllerEditedImage] as? UIImage) != nil
        {
            self.chosenImage = info[UIImagePickerControllerEditedImage] as! UIImage //2
            self.image_Data = UIImageJPEGRepresentation(self.chosenImage, 0.5)
            self.img_user.image = chosenImage
        }
        
        picker.dismiss(animated: true)
    }
}
