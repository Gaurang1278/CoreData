//
//  ViewController.swift
//  TestCore
//
//  Created by CT on 7/30/18.
//  Copyright © 2018 CT. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    let imagePicker = UIImagePickerController()
    var chosenImage = UIImage()
    var image_Data = UIImageJPEGRepresentation(UIImage(),0)
    var appDelegate = AppDelegate()
    var final_arr:NSMutableArray = NSMutableArray()
    var update_arr:NSMutableArray = NSMutableArray()
    
    @IBOutlet weak var table_view: UITableView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.navigationController?.navigationBar.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
       self.FetchData()
    }
    
    func FetchData()
    {
        let context = appDelegate.persistentContainer.viewContext
        let managedContext = context
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        
        do {
            let results =
                try managedContext.fetch(fetchRequest)
            
            if results.count != 0
            {
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
                
                do {
                    let results = try managedContext.fetch(fetchRequest)
                    let  Locations = results as! [Users]
                    
                    for location in Locations
                    {
                        print(location)
                        print(location.value(forKey: "name") ?? "no name")
                        
                        let data = location.value(forKey: "data") as! NSData
                        let unarchiveObject = NSKeyedUnarchiver.unarchiveObject(with: data as Data)
                        final_arr = unarchiveObject as! NSMutableArray
                        
                         update_arr =  NSMutableArray(array: final_arr.reverseObjectEnumerator().allObjects).mutableCopy() as! NSMutableArray

                        print(update_arr)
                        
                        table_view.reloadData()
                    }
                }
                catch let error as NSError
                {
                }
            }
            
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }
    
    //MARK:-Table view
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        return update_arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        let dict = self.update_arr[indexPath.row] as! NSDictionary
        cell.textLabel?.text = (dict["name"] as! String)
        cell.imageView?.image = UIImage(data:(dict["image"] as! Data),scale:1.0)
        return cell
    }
    
    @IBAction func doclickNext(_ sender: Any)
    {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let guardview = storyboard.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
        self.navigationController?.pushViewController(guardview, animated: true)
    }
    
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


